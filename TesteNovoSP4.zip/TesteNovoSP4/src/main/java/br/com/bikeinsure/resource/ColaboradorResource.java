package br.com.bikeinsure.resource;

import java.sql.SQLException;
import java.util.List;

import br.com.bikeinsure.exception.BadInfoException;
import br.com.bikeinsure.exception.IdNotFoundException;
import br.com.bikeinsure.model.Colaborador;
import br.com.bikeinsure.service.ColaboradorService;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.core.UriBuilder;
import jakarta.ws.rs.core.UriInfo;

@Path("/colaborador") // Ajustei o path para "/api/colaboradores"
public class ColaboradorResource {

	private ColaboradorService service;

	public ColaboradorResource() throws ClassNotFoundException, SQLException {
		service = new ColaboradorService();
	}

	// POST http://localhost:8080/07-WebApi/api/colaborador/ (Cadastrar um nao esta
	// certo
	// funcionario)
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response cadastrar(Colaborador colaborador, @Context UriInfo uri)
			throws ClassNotFoundException, SQLException {
		try {
			service.cadastrar(colaborador);
		
			UriBuilder uriBuilder = uri.getAbsolutePathBuilder();
		
			uriBuilder.path((colaborador.getNome()));
			
			return Response.created(uriBuilder.build()).build();
		} catch (BadInfoException e) {
			e.printStackTrace();
			// Retornar o status 400 bad request
			return Response.status(Status.BAD_REQUEST).entity(e.getMessage()).build();
		}
	}

	// GET http://localhost:8080/07-WebApi/api/colaborador (Listar todos os
	// funcionarios)
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Colaborador> lista() throws ClassNotFoundException, SQLException {
		return service.listar();
	}

	// DELETE http://localhost:8080/07-WebApi/api/funcionario/Rafael (Apagar um
	// produto)
	@DELETE
	@Path("/{idColaborador}")
	public Response remover(@PathParam("idColaborador") int idColaborador) throws ClassNotFoundException, SQLException {
		try {
			service.remover(idColaborador);
			return Response.noContent().build();
		} catch (IdNotFoundException e) {
			return Response.status(Status.NOT_FOUND).build();
		}
	}

	// PUT http://localhost:8080/07-WebApi/api/produto/1 (Atualizar um funcionario)
	@PUT
	@Path("/{idColaborador}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response atualizar(Colaborador colaborador, @PathParam("idColaborador") int idColaborador)
			throws ClassNotFoundException, SQLException {
		try {
			colaborador.setIdColaborador(idColaborador);
			service.atualizar(colaborador);
			return Response.ok().build();
		} catch (IdNotFoundException e) {
			return Response.status(Status.NOT_FOUND).build();
		} catch (BadInfoException e) {
			return Response.status(Status.BAD_REQUEST).entity(e.getMessage()).build();
		}
	}

}
