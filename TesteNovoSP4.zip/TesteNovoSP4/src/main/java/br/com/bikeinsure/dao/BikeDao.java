package br.com.bikeinsure.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.bikeinsure.exception.IdNotFoundException;
import br.com.bikeinsure.model.Bike;

public class BikeDao {

	private Connection conn;

	public BikeDao(Connection conn) {
		this.conn = conn;
	}
	
		public void cadastrar(Bike bike) throws ClassNotFoundException, SQLException {
			
			//Criar o objeto com o comando SQL
			PreparedStatement stm = conn.prepareStatement("INSERT INTO bike (id, nome_bike, preco, cor, nome_modelo, descricao_modelo, tamanho, marca, personalizada) values (?, ?, ?, ?, ?, ?, ?, ?, ?)");
	
			//Setar os valores no comando SQL
			stm.setInt(1, bike.getbikeId());
			stm.setString(2, bike.getNomeBike());
			stm.setDouble(3, bike.getPreco());
			stm.setString(4, bike.getCor());
			stm.setString(5, bike.getNomeModelo());
			stm.setString(6, bike.getDescricaoModelo());
			stm.setString(7, bike.getTamanho());
			stm.setString(8, bike.getMarca());
			stm.setString(9, bike.getPersonalizada());

			// Execução da consulta de inserção
			stm.executeUpdate();
		}
		
		public List<Bike> listar() throws ClassNotFoundException, SQLException {
			
		    PreparedStatement stm = conn.prepareStatement("SELECT * FROM bike"); // Corrigido para 'bike'
		    ResultSet result = stm.executeQuery();
		    List<Bike> lista = new ArrayList<Bike>();

		    while (result.next()) {
		        Bike bike = parse(result);
		        lista.add(bike);
		    }

		    return lista;
		}

		
		private Bike parse(ResultSet result) throws SQLException {
			int bikeId = result.getInt("bikeId");
			String nomeBike = result.getString("nome_bike");
		    double preco = result.getDouble("preco");
		    String cor = result.getString("cor");
		    String tamanho = result.getString("tamanho");
		    String marca = result.getString("marca");
		    String personalizada = result.getString("personalizada");
		    String nomeModelo = result.getString("nome_modelo");
		    String descricaoModelo = result.getString("descricao_modelo");
		   
		    Bike bike = new Bike(bikeId, nomeBike, preco, cor, nomeModelo, descricaoModelo, tamanho, marca, personalizada);

		    return bike;
		}
		// Método para deletar uma bike pelo código
		public void remover(int bikeId) throws ClassNotFoundException, SQLException, IdNotFoundException {
			
			PreparedStatement stm = conn.prepareStatement("DELETE FROM bike WHERE bikeId = ?");
			
			stm.setInt(1, bikeId);
			
			int linha = stm.executeUpdate();
			if (linha == 0)
				throw new IdNotFoundException("Id nao encontrado para remocao");
		}
		
		public void atualizar (Bike bike) throws ClassNotFoundException, SQLException, IdNotFoundException {
			
			//PreparedStatement
			PreparedStatement stm = conn.prepareStatement("update bike set nome_bike=?, preco=?, cor=?, nome_modelo=?, descricao_modelo=?, tamanho=?, marca=?, personalizada=? where bikeId=?"
			);
			
			stm.setString(1, bike.getNomeBike());
			stm.setDouble(2, bike.getPreco());
			stm.setString(3, bike.getCor());
			stm.setString(4, bike.getNomeModelo());
			stm.setString(5, bike.getDescricaoModelo());
			stm.setString(6, bike.getTamanho());
			stm.setString(7, bike.getMarca());
			stm.setString(8, bike.getPersonalizada());
			stm.setInt(9, bike.getbikeId());
			int linha = stm.executeUpdate();
			if (linha == 0)
				throw new IdNotFoundException("Nome nao encontrado para atualizar");
		}
		
		
		
		
		
		
		
	 // Método para pesquisar uma bike pelo código
	public Bike pesquisar(int codigo) throws SQLException, IdNotFoundException {
		// Preparação da consulta SQL para buscar uma bike pelo código
		PreparedStatement stm = conn.prepareStatement("select * from bike where id = ?");
		stm.setInt(1, codigo);

		// Execução da consulta
		ResultSet result = stm.executeQuery();

		// Verificação se a bike foi encontrada
		if (!result.next()) {
			throw new IdNotFoundException("Bike não encontrada");
		}

		// Recuperação dos dados da bike do ResultSet
		String nomeBike = result.getString("nome_bike");
		double preco = result.getDouble("preco");
		String cor = result.getString("cor");
		String tamanho = result.getString("tamanho");
		String marca = result.getString("marca");
		String personalizada = result.getString("personalizada");
		// Adição das colunas necessárias para inicializar o objeto Modelo
		String nomeModelo = result.getString("nome_modelo");
		String descricaoModelo = result.getString("descricao_modelo");
		int bikeId = result.getInt("bikeId");

		// Criação do objeto Bike com os dados recuperados
		Bike bike = new Bike(bikeId, nomeBike, preco, cor, nomeModelo, descricaoModelo, tamanho, marca,personalizada);
		return bike;
	}


	// Método para retornar todos os dados das bikes
	public ArrayList<Bike> retornarDados() {
		String sql = "select * from bike";
		ArrayList<Bike> retornarBikes = new ArrayList<>();
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if (rs != null) {
				while (rs.next()) {
					String nomeBike = rs.getString("nome_bike");
					double preco = rs.getDouble("preco");
					String cor = rs.getString("cor");
					String tamanho = rs.getString("tamanho");
					String marca = rs.getString("marca");
					String personalizada = rs.getString("personalizada");
					String nomeModelo = rs.getString("nome_modelo");
					String descricaoModelo = rs.getString("descricao_modelo");
					int bikeId = rs.getInt("bikeId");

					Bike bike = new Bike(bikeId, nomeBike, preco, cor, nomeModelo, descricaoModelo, tamanho, marca,
							personalizada);
					retornarBikes.add(bike);
				}
				return retornarBikes;
			} else {
				return null;
			}
		} catch (SQLException e) {
			return null;
		}
	}
}
