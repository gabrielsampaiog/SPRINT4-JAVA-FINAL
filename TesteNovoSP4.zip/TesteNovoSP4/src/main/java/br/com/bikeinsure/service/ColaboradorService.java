package br.com.bikeinsure.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import br.com.bikeinsure.dao.ColaboradorDao;
import br.com.bikeinsure.exception.BadInfoException;
import br.com.bikeinsure.exception.IdNotFoundException;
import br.com.bikeinsure.factory.ConnectionFactory;
import br.com.bikeinsure.model.Colaborador;

public class ColaboradorService {
	
	private ColaboradorDao colaboradorDao;
	
	 public ColaboradorService() throws ClassNotFoundException, SQLException {
 		Connection conn = ConnectionFactory.getConnection();
 		colaboradorDao = new ColaboradorDao(conn);
	      
	}

    public void cadastrar(Colaborador colaborador) throws ClassNotFoundException, SQLException, BadInfoException {
        //validar(colaborador);
        colaboradorDao.cadastrar(colaborador);
    }

    public List<Colaborador> listar() throws ClassNotFoundException, SQLException{
		return colaboradorDao.listar();
	}
    
    public void remover(int idColaborador) throws ClassNotFoundException, SQLException, IdNotFoundException {
		colaboradorDao.remover(idColaborador);
	}
    public void atualizar(Colaborador colaborador) throws ClassNotFoundException, SQLException, IdNotFoundException, BadInfoException {
		//validar(produto);
		colaboradorDao.atualizar(colaborador);
	}

	
}
