package br.com.bikeinsure.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import br.com.bikeinsure.dao.BikeDao;
import br.com.bikeinsure.exception.BadInfoException;
import br.com.bikeinsure.exception.IdNotFoundException;
import br.com.bikeinsure.factory.ConnectionFactory;
import br.com.bikeinsure.model.Bike;

public class BikeService {

    private BikeDao bikeDao;

    public BikeService() throws ClassNotFoundException, SQLException {
        Connection conn = ConnectionFactory.getConnection();
        bikeDao = new BikeDao(conn);
    }

    public void cadastrar(Bike bike) throws ClassNotFoundException, SQLException, BadInfoException {
        //validar(bike);
        bikeDao.cadastrar(bike);
    }

    public List<Bike> listar() throws ClassNotFoundException, SQLException{
    	return bikeDao.listar();
    }
    
    public void remover(int bikeId) throws ClassNotFoundException, SQLException, IdNotFoundException {
    	bikeDao.remover(bikeId);
    }
 
    public void atualizar(Bike bike) throws ClassNotFoundException, SQLException, IdNotFoundException, BadInfoException{
    	
    	bikeDao.atualizar(bike);
    }
}
