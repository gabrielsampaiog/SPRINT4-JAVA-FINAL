package br.com.bikeinsure.model;


public class Pessoa {

    private int idPessoa;
    private String nome;
    private String cpf;
    private int rg;
    private String dataNascimento;
    private String endereco;
    private String senha;
    private String email; 
    private String telefone;

    // Construtor sem parâmetros
    public Pessoa() {
        // Este é um construtor vazio necessário quando você também quer ter um construtor com parâmetros.
        // Caso contrário, Java fornecerá automaticamente um construtor padrão vazio.
    }

    public Pessoa(int idPessoa, String nome, String cpf, int rg, String dataNascimento, String endereco, String senha,
			String email, String telefone) {
		super();
		this.idPessoa = idPessoa;
		this.nome = nome;
		this.cpf = cpf;
		this.rg = rg;
		this.dataNascimento = dataNascimento;
		this.endereco = endereco;
		this.senha = senha;
		this.email = email;
		this.telefone = telefone;
	}



    // Getter e Setter para email
    public String getEmail() {
        return email;
    }

    // Método para verificar o formato do email
    public boolean verificarFormatoEmail(String email) {
        return email != null && email.matches(".+@.+\\..+");
    }
    
    public void setEmail(String email) {
        // Adicione verificação de formato de email
        if (!verificarFormatoEmail(email)) {
            throw new IllegalArgumentException("Formato de email inválido.");
        }
        this.email = email;
    }

    // Outros getters e setters
    public int getIdPessoa() {
  		return idPessoa;
  	}

  	public void setIdPessoa(int idPessoa) {
  		this.idPessoa = idPessoa;
  	}

  	public String getNome() {
  		return nome;
  	}

  	public void setNome(String nome) {
  		this.nome = nome;
  	}

  	public String getDataNascimento() {
  		return dataNascimento;
  	}

  	public void setDataNascimento(String dataNascimento) {
  		this.dataNascimento = dataNascimento;
  	}

  	public String getEndereco() {
  		return endereco;
  	}

  	public void setEndereco(String endereco) {
  		this.endereco = endereco;
  	}

  	public String getSenha() {
  		return senha;
  	}

  	public void setSenha(String senha) {
  		this.senha = senha;
  	}

  	public String getTelefone() {
  		return telefone;
  	}

  	public void setTelefone(String telefone) {
  		this.telefone = telefone;
  	}

  	public String getCpf() {
  		return cpf;
  	}

  	public int getRg() {
  		return rg;
  	}
    
  
	// Setter para CPF com verificação
    public void setCpf(String cpf) {
        // Adicione verificação de CPF
        if (!verificarCpf(cpf)) {
            throw new IllegalArgumentException("CPF inválido.");
        }
        this.cpf = cpf;
    }

  

	// Setter para RG com verificação
    public void setRg(int rg) {
        // Adicione verificação de RG
        if (rg <= 0) {
            throw new IllegalArgumentException("RG inválido.");
        }
        this.rg = rg;
    }

    // Método para verificar CPF utilizando algoritmo específico
    private boolean verificarCpf(String cpf) {
        // Verifica se o CPF tem 11 dígitos numéricos
        return cpf != null && cpf.matches("\\d{11}");
    }

}