package br.com.bikeinsure.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.bikeinsure.exception.IdNotFoundException;
import br.com.bikeinsure.model.Colaborador;

public class ColaboradorDao {

	private Connection conn;
	
	public ColaboradorDao(Connection conn) {
		this.conn = conn;
	}

	public void cadastrar(Colaborador colaborador) throws ClassNotFoundException, SQLException {

		PreparedStatement stm = conn
				.prepareStatement("INSERT INTO colaborador (idColaborador, nome, senha) values (?,?,?)");

		stm.setInt(1, colaborador.getIdColaborador());
		stm.setString(2, colaborador.getNome());
		stm.setString(3, colaborador.getSenha());

		stm.executeUpdate();
	}

	public List<Colaborador> listar() throws ClassNotFoundException, SQLException {

		PreparedStatement stm = conn.prepareStatement("select * from colaborador");

		ResultSet result = stm.executeQuery();
		List<Colaborador> lista = new ArrayList<Colaborador>();

		while (result.next()) {
			Colaborador colaborador = parse(result);
			lista.add(colaborador);
		}

		return lista;
	}

	private Colaborador parse(ResultSet result) throws SQLException {

		int idColaborador = result.getInt("idColaborador");
		String nome = result.getString("nome");
		String senha = result.getString("salario");

		Colaborador colaborador = new Colaborador(idColaborador, nome, senha);

		return colaborador;
	}

	public void remover(int idColaborador) throws ClassNotFoundException, SQLException, IdNotFoundException {

		// PreparedStatement
		PreparedStatement stm = conn.prepareStatement("delete from colaborador where id_colaborador = ?");
		// Setar os parametros na Query
		stm.setInt(1, idColaborador);
		// Executar a Query
		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("id nao encontrado para remocao");
	}

	public void atualizar(Colaborador colaborador) throws ClassNotFoundException, SQLException, IdNotFoundException {

		// PreparedStatement
		PreparedStatement stm = conn.prepareStatement("update colaborador set nome = ? where id_colaborador = ?");
		// Setar os parametros na Query
		stm.setString(1, colaborador.getNome());
		// stm.setDouble(1, 700);
		stm.setInt(2, colaborador.getIdColaborador());
		// Executar a Query
		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Nome n�o encontrado para atualizar");
	}
}
