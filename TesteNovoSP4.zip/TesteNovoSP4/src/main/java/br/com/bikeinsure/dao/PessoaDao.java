package br.com.bikeinsure.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.bikeinsure.exception.IdNotFoundException;
import br.com.bikeinsure.model.Pessoa;

public class PessoaDao {

    private Connection conn;

    public PessoaDao(Connection conn) {
        this.conn = conn;
    }

    // Método para cadastrar uma pessoa
    public void cadastrar(Pessoa pessoa) throws ClassNotFoundException, SQLException {
        PreparedStatement stm = conn.prepareStatement("INSERT INTO t_pessoa "
                + "(id_pessoa, nome, cpf, rg, data_nascimento, endereco, senha, email, telefone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

        stm.setInt(1, pessoa.getIdPessoa());
        stm.setString(2, pessoa.getNome());
        stm.setString(3, pessoa.getCpf());
        stm.setInt(4, pessoa.getRg());
        stm.setString(5, pessoa.getDataNascimento());
        stm.setString(6, pessoa.getEndereco());
        stm.setString(7, pessoa.getSenha());
        stm.setString(9, pessoa.getEmail());
        stm.setString(10, pessoa.getTelefone());

        stm.executeUpdate();
    }

    public List<Pessoa> listar() throws ClassNotFoundException, SQLException {

		PreparedStatement stm = conn.prepareStatement("select * from pessoa");

		ResultSet result = stm.executeQuery();
		List<Pessoa> lista = new ArrayList<Pessoa>();

		while (result.next()) {
			Pessoa pessoa = parse(result);
			lista.add(pessoa);
		}

		return lista;
	}

	private Pessoa parse(ResultSet result) throws SQLException {
		
		int idPessoa = result.getInt("id_pessoa");
		String nome = result.getString("nome");
        String cpf = result.getString("cpf");
        int rg = result.getInt("rg");
        String dataNascimento = result.getString("data_nascimento");
        String endereco = result.getString("endereco");
        String senha = result.getString("senha");
        String email = result.getString("email");
        String telefone = result.getString("telefone");
	
        Pessoa pessoa = new Pessoa(idPessoa, nome, cpf, rg, dataNascimento, endereco, senha, email, telefone);

		return pessoa;
	}
	
	public void remover(String nome) throws ClassNotFoundException, SQLException, IdNotFoundException {

		// PreparedStatement
		PreparedStatement stm = conn.prepareStatement("delete from pessoa where nome = ?");
		// Setar os parametros na Query
		stm.setString(1, nome);
		// Executar a Query
		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Nome n�o encontrado para remo��o");
	}
	
	public void atualizar(Pessoa pessoa) throws ClassNotFoundException, SQLException, IdNotFoundException {

		// PreparedStatement
		PreparedStatement stm = conn.prepareStatement("update pessoa set nome = ? where cpf = ?");
		// Setar os parametros na Query
		stm.setString(1, pessoa.getNome());
		//stm.setDouble(1, 700);
		stm.setString(2, pessoa.getCpf());
		// Executar a Query
		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Nome n�o encontrado para atualizar");
	}

}

