package br.com.bikeinsure.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import br.com.bikeinsure.dao.SegurosDao;
import br.com.bikeinsure.exception.BadInfoException;
import br.com.bikeinsure.exception.IdNotFoundException;
import br.com.bikeinsure.factory.ConnectionFactory;
import br.com.bikeinsure.model.Seguros;

public class SegurosService {

    private SegurosDao segurosDao;

    public SegurosService() throws ClassNotFoundException, SQLException {
        Connection conn = ConnectionFactory.getConnection();
        segurosDao = new SegurosDao(conn);
    }

    public void cadastrar(Seguros seguros) throws ClassNotFoundException, SQLException, BadInfoException {
        //validar(seguro);
        segurosDao.cadastrar(seguros);
    }
    public List<Seguros> listar() throws ClassNotFoundException, SQLException{
		return segurosDao.listar();
	}
    public void remover(int cdSeguro) throws ClassNotFoundException, SQLException, IdNotFoundException {
		segurosDao.remover(cdSeguro);
	}
    
    public void atualizar(Seguros seguros) throws ClassNotFoundException, SQLException, IdNotFoundException, BadInfoException {
		//validar(produto);
		segurosDao.atualizar(seguros);
	}
}
