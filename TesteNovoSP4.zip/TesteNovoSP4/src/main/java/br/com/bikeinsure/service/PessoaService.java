package br.com.bikeinsure.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import br.com.bikeinsure.dao.PessoaDao;
import br.com.bikeinsure.exception.BadInfoException;
import br.com.bikeinsure.exception.IdNotFoundException;
import br.com.bikeinsure.factory.ConnectionFactory;
import br.com.bikeinsure.model.Pessoa;


public class PessoaService {

	private PessoaDao pessoaDao;

	public PessoaService() throws ClassNotFoundException, SQLException {
		Connection conn = ConnectionFactory.getConnection();
		pessoaDao = new PessoaDao(conn);
	}

	public void cadastrar(Pessoa pessoa) throws ClassNotFoundException, SQLException, BadInfoException {
		// validar(pessoa);
		pessoaDao.cadastrar(pessoa);
	}

	public List<Pessoa> listar() throws ClassNotFoundException, SQLException {
		return pessoaDao.listar();
	}

	public void remover(String nome) throws ClassNotFoundException, SQLException, IdNotFoundException {
		pessoaDao.remover(nome);
	}

	public void atualizar(Pessoa pessoa)
			throws ClassNotFoundException, SQLException, IdNotFoundException, BadInfoException {
		// validar(produto);
		pessoaDao.atualizar(pessoa);
	}

}
