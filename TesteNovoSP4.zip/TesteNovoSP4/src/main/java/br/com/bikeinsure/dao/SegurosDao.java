package br.com.bikeinsure.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.bikeinsure.exception.IdNotFoundException;
import br.com.bikeinsure.model.Seguros;


public class SegurosDao {

    private Connection conn;

    public SegurosDao(Connection conn) {
        this.conn = conn;
    }

    public void cadastrar(Seguros seguro) throws ClassNotFoundException, SQLException {

		// Criar o objeto com o comando SQL configuravel
    	PreparedStatement stm = conn.prepareStatement("INSERT INTO t_seguro "
                + "(cd_seguro, tipo_seguro, inicio_seguro, fim_seguro, status_seguro) VALUES (?, ?, ?, ?, ?)");

		// Setar os valores no comando SQL
    	  stm.setInt(1, seguro.getCdSeguro());
          stm.setString(2, seguro.getTipoSeguro());
          stm.setString(3, seguro.getInicioSeguro());
          stm.setString(4, seguro.getFimSeguro());
          stm.setString(5, seguro.getStatusSeguro());

		// Executar o comando SQL
		stm.executeUpdate();
	}
    public List<Seguros> listar() throws ClassNotFoundException, SQLException {

		PreparedStatement stm = conn.prepareStatement("select * from seguros");

		ResultSet result = stm.executeQuery();
		List<Seguros> lista = new ArrayList<Seguros>();

		while (result.next()) {
			Seguros seguros = parse(result);
			lista.add(seguros);
		}

		return lista;
	}

	private Seguros parse(ResultSet result) throws SQLException {

		int cdSeguro = result.getInt("cd_seguro");
		String tipoSeguro = result.getString("tipo_seguro");
        String inicioSeguro = result.getString("inicio_seguro");
        String fimSeguro = result.getString("fim_seguro");
        String statusSeguro = result.getString("status_seguro");

		Seguros seguros = new Seguros(cdSeguro, tipoSeguro, inicioSeguro, fimSeguro, statusSeguro);

		return seguros;
	}
	

	public void remover(int cdSeguro) throws ClassNotFoundException, SQLException, IdNotFoundException {

		// PreparedStatement
		PreparedStatement stm = conn.prepareStatement("delete from seguros where cd_seguro = ?");
		// Setar os parametros na Query
		stm.setInt(1, cdSeguro);;
		// Executar a Query
		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("Nome nao encontrado para remocao");
	}

	public void atualizar(Seguros seguros) throws ClassNotFoundException, SQLException, IdNotFoundException {

		// PreparedStatement
		PreparedStatement stm = conn.prepareStatement("update seguros set tipoSeguros = ? where cd_seguros = ?");
		// Setar os parametros na Query
		stm.setString(1, seguros.getTipoSeguro());
		//stm.setDouble(1, 700);
		stm.setInt(2, seguros.getCdSeguro());
		// Executar a Query
		int linha = stm.executeUpdate();
		if (linha == 0)
			throw new IdNotFoundException("codigo n�o encontrado para atualizar");
	}

	

}