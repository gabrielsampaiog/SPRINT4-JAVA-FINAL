CREATE TABLE bike (
    bikeId NUMBER PRIMARY KEY,
    nome_bike VARCHAR2(255),
    preco NUMBER(10,2),
    cor VARCHAR2(50),
    nome_modelo VARCHAR2(100),
    descricao_modelo VARCHAR2(4000),
    tamanho VARCHAR2(10),
    marca VARCHAR2(100),
    personalizada VARCHAR2(3)
);
